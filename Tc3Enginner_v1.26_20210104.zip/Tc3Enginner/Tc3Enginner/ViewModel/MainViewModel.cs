using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using System;
using System.Collections.Generic;
using System.IO;
using Tc3Enginner.Common;
using Tc3Enginner.Model;

namespace Tc3Enginner.ViewModel
{
    /// <summary>
    /// This class contains properties that the main View can data bind to.
    /// <para>
    /// Use the <strong>mvvminpc</strong> snippet to add bindable properties to this ViewModel.
    /// </para>
    /// <para>
    /// You can also use Blend to data bind with the tool's support.
    /// </para>
    /// <para>
    /// See http://www.galasoft.ch/mvvm
    /// </para>
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        #region
        //propery
        public List<Master> _peripherals;
        public List<Master> Peripherals
        {
            get
            {
               // if(_peripherals == null)
               // {
               //     GetPeripherals();
               // }
                return _peripherals;
            }
            set
            {
                if(value != _peripherals)
                {
                    _peripherals = value;
                    RaisePropertyChanged( ()=> Peripherals);
                }
            }
        }

        private SlnLocation _curSlnPath = new SlnLocation();
        public SlnLocation CurSlnPath
        {
            get
            {
                return _curSlnPath;
            }

            set
            {
                _curSlnPath = value;
                RaisePropertyChanged(() => CurSlnPath);
            }
        }

        //command
        private RelayCommand _onSaveClick;
        public RelayCommand OnSaveClick
        {
            get
            {
                if(_onSaveClick == null)
                { return new RelayCommand(() => SaveDeviceConfig(_peripherals)); }
                return _onSaveClick;
            }
            set { _onSaveClick = value; }
        }


        private RelayCommand _selectSln;
        public RelayCommand SelectSln
        {
            get
            {
                if (_selectSln == null)
                { return new RelayCommand(() => SelectTc3Sln()); }
                return _selectSln;
            }
            set { _selectSln = value; }
        }

        private RelayCommand _readIOConfig;
        public RelayCommand ReadIOConfig
        {
            get
            {
                if (_readIOConfig == null)
                { return new RelayCommand(() => ReadIOConfigFromSln()); }
                return _readIOConfig;
            }
            set { _readIOConfig = value; }
        }

        private RelayCommand _writeBMKValue;
        public RelayCommand WriteBMKValue
        {
            get
            {
                if (_writeBMKValue == null)
                { return new RelayCommand(() => WriteBMKValueToSln()); }
                return _writeBMKValue;
            }
            set { _writeBMKValue = value; }
        }

        private RelayCommand _exportIO;
        public RelayCommand ExportIO
        {
            get
            {
                if (_exportIO == null)
                { return new RelayCommand(() => ExportIOVar()); }
                return _exportIO;
            }
            set { _exportIO = value; }
        }

        private RelayCommand _linkVaribles;
        public RelayCommand LinkVariables
        {
            get
            {
                if (_linkVaribles == null)
                { return new RelayCommand(() => LinkIOVariables()); }
                return _linkVaribles;
            }
            set { _linkVaribles = value; }
        }
        #endregion

        private Tc3Solution MySln = new Tc3Solution();

        //get device IO data
        //private string path = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "=000+S-A620-A1 (EtherCAT).xti";
        private string path = String.Format("{0}\\=000+S-A620-A1 (EtherCAT).xti", Environment.CurrentDirectory);

        /// <summary>
        /// ��ȡIO�����ļ� *.xti
        /// </summary>
        /// <param name="pathInfo"></param>
        private void ReadIOConfigFromSln()
        {
            if (_curSlnPath == null || _curSlnPath.FilePath == null)
            {
                string msg = "��ѡ��TwinCat3��Ŀ��";
                ShowMessage(msg);

            }
            else
            {
                if (!MessageFilter.IsRegistered)
                    MessageFilter.Register();
                Peripherals = MySln.ReadIOConfigFromSln(_curSlnPath);

                MessageFilter.Revoke();
            }


        }

        /// <summary>
        /// write IO BMK value to TC3 solution
        /// </summary>
        private void WriteBMKValueToSln()
        {
            if (_curSlnPath == null || _curSlnPath.FilePath == null || _peripherals == null)
            {
                string msg = "��ѡ��TwinCat3��Ŀ����ȡ��̬���ã�";
                ShowMessage(msg);

            }
            else
            {
                if (!MessageFilter.IsRegistered)
                    MessageFilter.Register();

                MySln.WriteBMKValueToSln(_peripherals, _curSlnPath,true);
                MySln.ConsumeMapping(_curSlnPath.FilePath);
                MessageFilter.Revoke();
            }
        }

        /// <summary>
        /// export plc peripheral io
        /// </summary>
        private void ExportIOVar()
        {
            if (_curSlnPath == null || _curSlnPath.FilePath == null || _peripherals == null)
            {
                string msg = "��ѡ��TwinCat3��Ŀ����ȡ��̬���ã�";
                ShowMessage(msg);

            }
            else
            {
                if (!MessageFilter.IsRegistered)
                    MessageFilter.Register();

                MySln.ExportIo(_peripherals,_curSlnPath.FilePath);

                MessageFilter.Revoke();
            }
        }

        /// <summary>
        /// link variables
        /// </summary>
        private void LinkIOVariables()
        {
            if (_curSlnPath == null || _curSlnPath.FilePath == null || _peripherals == null)
            {
                string msg = "��ѡ��TwinCat3��Ŀ����ȡ��̬���ã�";
                ShowMessage(msg);

            }
            else
            {
                if (!MessageFilter.IsRegistered)
                    MessageFilter.Register();

                MySln.LinkVariables(_peripherals,_curSlnPath);

                MessageFilter.Revoke();
            }
        }

        /// <summary>
        /// save device config
        /// </summary>
        /// <param name="device"></param>
        private void SaveDeviceConfig(List<Master> device)
        {
            
            if (_curSlnPath == null || _curSlnPath.FilePath == null || _peripherals == null)
            {
                string msg = "��ѡ��TwinCat3��Ŀ����ȡ��̬���ã�";
                ShowMessage(msg);

            }
            else
            {
                if (!MessageFilter.IsRegistered)
                    MessageFilter.Register();

                //MySln.SaveIOConfig(device, _curSlnPath);
                MySln.WriteBMKValueToSln(_peripherals, _curSlnPath, false);

                MessageFilter.Revoke();
            }
        }

        #region
        /// <summary>
        /// ��Tc3Slnѡ��Ի���
        /// </summary>
        private void SelectTc3Sln()
        {
            //����һ�����ļ��ĶԻ���
            Microsoft.Win32.OpenFileDialog dialog = new Microsoft.Win32.OpenFileDialog()
            {
                Filter = "All Files|*.sln",
                //InitialDirectory = @"D:\";
            };
            //����ShowDialog()������ʾ�öԻ��򣬸÷����ķ���ֵ�����û��Ƿ�����ȷ����ť
            if (dialog.ShowDialog().GetValueOrDefault())            {
                _curSlnPath.FilePath =  dialog.FileName;                _curSlnPath.FileName = Path.GetFileName(dialog.FileName);                _curSlnPath.Directory = Path.GetDirectoryName(dialog.FileName);                Tc3Solution.CurProjectPath = dialog.FileName;

                //read config from file *.xti
                string _fileNameWithoutExtention = Path.GetFileNameWithoutExtension(_curSlnPath.FilePath);
                string _ioInfoPath = _curSlnPath.Directory + @"\ConfigFolder\Backup\IoInfo.xti";                if (File.Exists(_ioInfoPath))                   Peripherals =  MySln.ReadIoConfigFromFile(_ioInfoPath);            }            else
            {
                //Todo
            }
        }
        #endregion

        /// <summary>
        /// Message box from Tc3Solution
        /// </summary>
        /// <param name="msg"></param>
        public static void ShowMessage(string msg)
        {
            //��ViewAlertλTokon��־��������Ϣ����
            Messenger.Default.Send<string>(msg, "ViewIndicate");
        }
    }
}