﻿using GalaSoft.MvvmLight.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Tc3Enginner.Model;

namespace Tc3Enginner
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //消息标志token：ViewAlert，用于标识只阅读某个或者某些Sender发送的消息，并执行相应的处理，所以Sender那边的token要保持一致
            //执行方法Action：ShowReceiveInfo，用来执行接收到消息后的后续工作，注意这边是支持泛型能力的，所以传递参数很方便。
            Messenger.Default.Register<ConfirmMsgArgs>(this, "ViewAlert", ShowConfirmInfo);
            Messenger.Default.Register<string>(this, "ViewIndicate", ShowIndicateInfo);
            //卸载当前(this)对象注册的所有MVVMLight消息
            this.Unloaded += (sender, e) => Messenger.Default.Unregister(this);
        }
        /// <summary>
        /// 接收到消息后的后续工作：根据返回来的信息弹出消息框
        /// </summary>
        /// <param name="msg"></param>
        private void ShowConfirmInfo(ConfirmMsgArgs msg)
        {
            if (MessageBox.Show(msg.Content, msg.Title, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                msg.Result = true;
            else
                msg.Result = false;
        }
        private void ShowIndicateInfo(string msg)
        {
            MessageBox.Show(msg);
        }



        #region
        ///实现从Excel复制数据粘贴到dataGrid
        /// <summary>
        /// 粘贴处理剪贴板
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PasteCommand(object sender, ExecutedRoutedEventArgs e)
        {
            // 获取剪切板的内容，并按行分割     
            string pasteText = Clipboard.GetText();
            if (string.IsNullOrEmpty(pasteText))
                return;
            int cIndex = -1;
            int rIndex = -1;
            if (DataListView.SelectedCells.Count > 0)
            {
                DataGridCellInfo dgcInfo = DataListView.SelectedCells[0];
                cIndex = dgcInfo.Column.DisplayIndex;

                Variable dii = dgcInfo.Item as Variable;
                rIndex = GetDinfoIndex(dii);
               // Console.WriteLine("(" + cIndex.ToString() + "," + rIndex.ToString() + ")");
            }
            string[] Rinfo = pasteText.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            if (cIndex > -1 && rIndex > -1)
            {
                int rSum = Math.Min(Rinfo.Length, DataListView.Items.Count - rIndex);
                for (int i = 0; i < rSum; i++)
                {
                    string[] Cinfo = Rinfo[i].Split(new string[] { "\t" }, StringSplitOptions.RemoveEmptyEntries);
                    int cSum = Math.Min(Cinfo.Length, DataListView.Columns.Count - cIndex);
                    for (int j = 0; j < cSum; j++)
                    {
                        DataGridColumn dgcC = DataListView.Columns[cIndex + j];
                        try
                        {
                            (DataListView.Columns[cIndex + j].GetCellContent(DataListView.Items[rIndex + i]) as TextBlock).Text = Cinfo[j];
                        }
                        catch
                        {

                        }
                    }
                }
                //DataListView.Items.Refresh();
            }
           // Console.WriteLine(pasteText);

        }
        private int GetDinfoIndex(Variable di)
        {
            Terminal _selectedTerminal = treeListView.SelectedItem as Terminal;
            List<Variable> _selectedVars = _selectedTerminal.Variables;
            if (_selectedVars.Contains(di))
            {
                return _selectedVars.IndexOf(di);
            }
            else
            {
                return -1;
            }
        }
        #endregion
    }
}
