﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCatSysManagerLib;

namespace Tc3Enginner.Common
{
    class ExceptionHandler
    {
        public static void RunWithOutRejectedAction<T>(Action<T> action, T t)
        {
            bool hasException;
            do
            {
                try
                {
                    action(t);
                    hasException = false;
                }
                catch (System.Runtime.InteropServices.COMException e)
                {
                    if (e.ErrorCode == -2147418111)
                    {
                        hasException = true;
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            } while (hasException);
        }


        public static T RunWithOutRejectedFunc<T>(Func<ITcSmTreeItem, string, T> func, ITcSmTreeItem parent, string bStrBefore)
        {
            var result = default(T);
            bool hasException;
            do
            {
                try
                {
                    hasException = false;
                    result = func(parent, bStrBefore);                   
                }
                catch (System.Runtime.InteropServices.COMException e)
                {
                    if (e.ErrorCode == -2147418111)
                    {
                        hasException = true;
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            } while (hasException);
            return result;
        }
    }
}
