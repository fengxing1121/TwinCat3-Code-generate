﻿using EnvDTE;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using Tc3Enginner.Model;
using Tc3Enginner.ViewModel;
using TCatSysManagerLib;

namespace Tc3Enginner.Common
{
    public partial class Tc3Solution
    {
        #region
        //feilds
        dteHelper _dteHelp = new dteHelper();
        private string vsInstance = "TWINCAT_SHELL";
        public static string CurProjectPath;        
        private Solution solution;
        private String _slnFolder;

        private Project _project;
        public Project Project
        {
            get { return _project ?? (_project = grabSolutionProject(CurProjectPath)); }
            set { _project = value; }
        }

        private ITcSysManager13 _systemManager;
        public ITcSysManager13 SystemManager
        {
            get { return _systemManager ?? (_systemManager =(ITcSysManager13)Project.Object); }
            set { _systemManager = value; }
        }

        private ITcSmTreeItem _io;
        public ITcSmTreeItem Io
        {
            get { return _io ?? (_io = SystemManager.LookupTreeItem("TIID")); }
            set { _io = value; }
        }

        public String SlnFolder
        {
            get { return _slnFolder ?? (_slnFolder = ""); }
            set { _slnFolder = value; }
        }

        private ReadConfig _readCfg = new ReadConfig();
        private WriteIOValue _writeIOValue = new WriteIOValue();
        private List<Master> _peripherals;
        #endregion

        /// <summary>
        /// Quick setup method for opening TWINCAT_XAE
        /// Contains default parameters for visibility
        /// </summary>
        /// <returns>Visual Studio Solution Object</returns>
        public Solution quickSetupDTE()
        {
            return setupDTE(vsInstance, true, false, true);
        }

        /// <summary>
        /// Create visual studio instance
        /// </summary>
        /// <param name="appID">Visual studio version</param>
        /// <param name="ideVisible">Visibility</param>
        /// <param name="suppressUI">No idea</param>
        /// <param name="userControl">Allow user control</param>
        /// <returns>Visual Studio Solution Object</returns>
        public Solution setupDTE(string appID, bool ideVisible, bool suppressUI, bool userControl)
        {
            if (!MessageFilter.IsRegistered)
                MessageFilter.Register();
            environmentDTE vsDTE = new environmentDTE();
            vsDTE.Dte = vsDTE.CreateDTE(appID, ideVisible, suppressUI, userControl);
            return vsDTE.Dte.Solution;
        }

        /// <summary>
        /// Opens a given TwinCAT solution file
        /// </summary>
        /// <param name="solutionFilePath"></param>
        /// <returns></returns>
        public Solution openSolution(string SlnPath)    //Open existing TwinCAT solution
        {
            try
            {
                solution = quickSetupDTE();
                solution.Open(SlnPath);
                SlnFolder = new FileInfo(SlnPath).Directory.FullName;                               
            }
            catch
            {
                //throw new ApplicationException($"Unable to open '{SlnPath}'");
                //未找到IO配置文件夹，弹出错误窗口
                string msg = "无法打开项目：" + SlnPath;
                MainViewModel.ShowMessage(msg);
            }
            return solution;
        }

        /// <summary>
        /// read IO config from Tc3 solution
        /// </summary>
        /// <param name="SlnPathInfo"></param>
        /// <returns></returns>
        public List<Master> ReadIOConfigFromSln(SlnLocation SlnPathInfo)
        {
            //get solution instance
            grabSolutionProject(CurProjectPath);

            string configFolder = SlnPathInfo.Directory + @"\ConfigFolder";
            if (!Directory.Exists(configFolder))
                Directory.CreateDirectory(configFolder);
            string _ioConfigBackupFile = configFolder + @"\ioConfig.xti";
            if (!File.Exists(_ioConfigBackupFile))
                File.Create(_ioConfigBackupFile).Dispose();
            
            //look up EtherCAT config
            ITcSmTreeItem IoChild;
            bool EtherCateConfigExist = false;
            for (int i = 1; i <= Io.ChildCount; i++)
            {
                IoChild = Io.get_Child(i);
                if (IoChild.Name.Contains("EtherCAT"))
                {
                    EtherCateConfigExist = true;

                    //save current solution data to file
                    Io.ExportChild(IoChild.Name, _ioConfigBackupFile);

                    //read data from file
                    _peripherals = _readCfg.ReadIoFromTcSln(_ioConfigBackupFile, _peripherals, true);

                    //generate mapping infomation
                    GenerateMappingInfo(SlnPathInfo.FilePath);
                }

                
            }
            //don't find EtherCat config
            if (!EtherCateConfigExist)
            {
                //未找到EtherCat IO配置文件，弹出错误窗口
                string msg = "Device中未找到名称中包含'EtherCAT'的io硬件配置！";
                MainViewModel.ShowMessage(msg);
            }

            //Copying *.xti io file to save curent data,  bug exist when modify io but custom don't save it in Tc3
            #region
            /*
            string _fileNameWithoutExtention = Path.GetFileNameWithoutExtension(SlnPathInfo.FilePath);
            string _ioConfigPath = SlnPathInfo.Directory + @"\"+ _fileNameWithoutExtention + @"\_Config\IO";
            string _eFile = "";
            if (Directory.Exists(_ioConfigPath))
            {
                bool fileFound = false;
                string[] _configFile = Directory.GetFiles(_ioConfigPath, "*.xti");                
                foreach (string ethercatFile in _configFile)
                {
                    if (ethercatFile.Contains("EtherCAT"))
                    {
                        fileFound = true;
                        _eFile = ethercatFile;
                        _peripherals = _readCfg.ReadIoFromTcSln(_eFile,_peripherals,true);
                        GenerateMappingInfo(SlnPathInfo.FilePath);
                    }
                    if(!fileFound)
                    {
                        //未找到EtherCate配置文件，弹出错误窗口
                        string msg = "未找到文件" + _eFile;
                        MainViewModel.ShowMessage(msg);
                    }
                }
            }
            else
            {
                //未找到IO配置文件夹，弹出错误窗口
                string msg = "未找到文件夹" + _ioConfigPath;
                MainViewModel.ShowMessage(msg);
            }
            */
            #endregion
            return _peripherals;
        }

        /// <summary>
        /// read io config from *.xti file
        /// </summary>
        /// <param name="ioInfoPath"></param>
        /// <returns></returns>
        public List<Master> ReadIoConfigFromFile(string ioInfoPath)
        {
            _peripherals = _readCfg.ReadIoFromTcSln(ioInfoPath, _peripherals, false);

            return _peripherals;
        }

        /// <summary>
        /// write IO Value to tc3 solution
        /// </summary>
        /// <param name="Device"></param>
        /// <param name="SlnPathInfo"></param>
        public void WriteBMKValueToSln(List<Master> Device, SlnLocation SlnPathInfo , bool WriteValueToTc3)
        {
            //check solution instance
            grabSolutionProject(CurProjectPath);

            string _ioConfigBackupFile;
            string _fileNameWithoutExtention = Path.GetFileNameWithoutExtension(SlnPathInfo.FilePath);
            string ConfigFolder = SlnPathInfo.Directory + @"\ConfigFolder";
            if(!Directory.Exists(ConfigFolder))
                Directory.CreateDirectory(ConfigFolder);
            if (WriteValueToTc3)
            {
                _ioConfigBackupFile = ConfigFolder + @"\ioConfig.xti";
                if (!File.Exists(_ioConfigBackupFile))
                    File.Create(_ioConfigBackupFile);
            }                
            else
            {
                if(!Directory.Exists(ConfigFolder+@"\Backup"))
                    Directory.CreateDirectory(ConfigFolder + @"\Backup");
                _ioConfigBackupFile = ConfigFolder + @"\Backup\ioInfo.xti";
            }
                
            //look up EtherCAT config
            ITcSmTreeItem IoChild;
            bool EtherCateConfigExist = false;
            for(int i = 1; i <= Io.ChildCount; i++)
            {
                IoChild = Io.get_Child(i);
                if (IoChild.Name.Contains("EtherCAT"))
                {
                    EtherCateConfigExist = true;

                    //save current solution data to file
                    Io.ExportChild(IoChild.Name, _ioConfigBackupFile);

                    //save new data to xti file
                    _writeIOValue.SaveData(Device, _ioConfigBackupFile, WriteValueToTc3);

                    //witre value to tc3 sln
                    string itemBefore = "";
                    if (i < Io.ChildCount)
                        itemBefore = Io.get_Child(i+1).Name;
                    if (WriteValueToTc3)
                        importIoXti(_ioConfigBackupFile, IoChild.Name, itemBefore);
                }               
            }

            //don't find EtherCat config
            if (!EtherCateConfigExist)
            {
                //未找到EtherCat IO配置文件，弹出错误窗口
                string msg = "Device中未找到名称中包含'EtherCAT'的io硬件配置！";
                MainViewModel.ShowMessage(msg);
            }

            //Copying *.xti io file to save curent data,  bug exist when modify io but custom don't save it in Tc3
            #region
            /*
            //find io config file
            string _ioConfigPath = SlnPathInfo.Directory + @"\" + _fileNameWithoutExtention + @"\_Config\IO";
            string _eFile = "";
            if (Directory.Exists(_ioConfigPath))
            {
                string[] _configFile = Directory.GetFiles(_ioConfigPath, "*.xti");
                foreach (string ethercatFile in _configFile)
                {
                    if (ethercatFile.IndexOf("EtherCat") != 0)
                    {
                        _eFile = ethercatFile;
                        // _writeIOValue.SaveData(Device, _eFile);
                        FileInfo ethercatFileInfo = new FileInfo(_eFile);
                        ethercatFileInfo.CopyTo(_ioConfigBackupFile, true);

                        //save data to xti file
                        _writeIOValue.SaveData(Device, _ioConfigBackupFile, WriteValueToTc3);
                        
                        //witre value to tc3 sln
                        if(WriteValueToTc3)
                           importIoXti(_ioConfigBackupFile, _eFile);

                    }
                    else
                    {
                        //未找到EtherCat IO配置文件，弹出错误窗口
                        string msg = "未找到EtherCat IO配置文件" + _eFile;
                        MainViewModel.ShowMessage(msg);
                    }
                }
            }
            else
            {
                //未找到IO配置文件夹，弹出错误窗口
                string msg = "未找到文件" + _eFile;
                MainViewModel.ShowMessage(msg);
            }
            */
            #endregion
        }

        /// <summary>
        /// save data in *.xti file, don't write to Tc3 solution
        /// </summary>
        /// <param name="Device"></param>
        public void SaveIOConfig(List<Master> Device, SlnLocation SlnPathInfo)
        {
            #region
            //select a filepath to save data
            
            string _savePath;
            //创建一个保存文件的对话框
            Microsoft.Win32.SaveFileDialog dialog = new Microsoft.Win32.SaveFileDialog()
            {
                Filter = "All Files|*.xti"
            };           //调用ShowDialog()方法显示该对话框，该方法的返回值代表用户是否点击了确定按钮            if (dialog.ShowDialog().GetValueOrDefault())            {                _savePath = dialog.FileName;
                if (File.Exists(_savePath))
                    File.Create(_savePath).Dispose();
                _writeIOValue.SaveData(Device, _savePath, false);
            }            else             {                //Todo            }
        
            #endregion

            /*
            //save data in defined path

            //get solution instance
            grabSolutionProject(CurProjectPath);

            string _fileNameWithoutExtention = Path.GetFileNameWithoutExtension(SlnPathInfo.FilePath);
            string _ioSavePath = SlnPathInfo.Directory + @"\" + _fileNameWithoutExtention + @"\_Config\IO\DataBackup\ioBackup.xml";
            if (File.Exists(_ioSavePath))
                File.Create(_ioSavePath);

            //write data
            _writeIOValue.SaveData(Device, _ioSavePath,false);
            */
        }

        /// <summary>
        /// 导入*.xti 硬件配置文件
        /// </summary>
        /// <returns></returns>
        public Boolean importIoXti(string file,string DeviceName,string itemBefore)
        {
            string _deviceName = Path.GetFileNameWithoutExtension(DeviceName);
            try
            {
                Io.DeleteChild(_deviceName);
                Io.ImportChild(file, itemBefore, true, _deviceName);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public Project grabSolutionProject(string path)
        {
            if (!MessageFilter.IsRegistered)
                MessageFilter.Register();
            //get progID
            string progId = VSVersion.ReturnVersion(vsInstance);

            //call dteHelper to find current project active
            DTE dte = _dteHelp.attachToExistingDte(path, progId);
            if(dte != null)
            {                
                //Using the loaded solution, load in the project object using the first availabe project in the solution
                Project = dte.Solution.Projects.Item(1);
                string _proName = dte.Solution.FileName;
            }
            else
            {
                openSolution(path);
                Project = solution.Projects.Item(1);
                string _proName = Project.FileName;
            }
            return Project;
        }
    }
}
