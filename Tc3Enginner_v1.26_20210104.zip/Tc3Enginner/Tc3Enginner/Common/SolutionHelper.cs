﻿using EnvDTE;
using EnvDTE80;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using VSLangProj;

namespace Tc3Enginner.Common
{
    class SolutionHelper
    {

        public static bool AddFilesToProject(Solution Sln,string curSlnPath)
        {
            bool _slnOpened = false;
            try
            {
                List<string> solutionName = GetAllOpenedSolutions();
                if (solutionName != null)
                {
                    foreach (string item in solutionName)
                    {
                        if (item == curSlnPath)
                        {
                            //Sln.p.ProjectItems.AddFromFile(file);
                            Sln.Projects.Item(1).ProjectItems.AddFromFile(curSlnPath);
                            Sln.Projects.Item(1).Save();
                            _slnOpened = true;
                        }
                    }
                }
            }
            finally
            {
            }
            return _slnOpened;
        }

        private static List<string> GetAllOpenedSolutions()
        {
            List<string> solutionName =new List<string>();
            IRunningObjectTable rot;
            IEnumMoniker enumMoniker;
            int retVal = GetRunningObjectTable(0, out rot);

            if (retVal == 0)
            {
                rot.EnumRunning(out enumMoniker);

                IntPtr fetched = IntPtr.Zero;
                IMoniker[] moniker = new IMoniker[1];
                while (enumMoniker.Next(1, moniker, fetched) == 0)
                {
                    IBindCtx bindCtx;
                    CreateBindCtx(0, out bindCtx);
                    string displayName;
                    moniker[0].GetDisplayName(bindCtx, null, out displayName);
                    // Console.WriteLine("Display Name: {0}", displayName);
                    bool isVisualStudio = displayName.Contains(".sln");
                    if (isVisualStudio)
                    {
                        solutionName.Add(displayName);
                    }
                }
            }
            return solutionName;
        }

        [DllImport("ole32.dll")]
        private static extern void CreateBindCtx(int reserved, out IBindCtx ppbc);

        [DllImport("ole32.dll")]
        private static extern int GetRunningObjectTable(int reserved, out IRunningObjectTable prot);
    }

}
