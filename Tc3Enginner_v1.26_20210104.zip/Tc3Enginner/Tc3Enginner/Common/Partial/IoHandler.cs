﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xaml;
using System.Xml;
using System.Xml.Linq;
using Tc3Enginner.Model;
using Tc3Enginner.ViewModel;
using TCatSysManagerLib;

namespace Tc3Enginner.Common
{
    public partial class Tc3Solution
    {
        //field and propery
        #region
        /// <summary>
        /// XAE Base Template new (>= TwinCAT 3.1)
        /// </summary>
        public static string vsXaeTemplateName = "TwinCAT Project.tsproj";

        /// <summary>
        /// Gets the Path of the TwinCAT XAE Base Template
        /// </summary>
        /// <value>The vs xae template path.</value>
        public static string vsXaeEmptyTemplatePath = @"C:\TwinCAT\3.x\Components\Plc\PlcTemplate\Plc Templates\Empty PLC Template.plcproj";
        public static string vsXaeStandardTemplatePath = @"C:\TwinCAT\3.x\Components\Plc\PlcTemplate\Plc Templates\Standard PLC Template.plcproj";

        public static string tcRepositoryPath = @"C:\TwinCAT\3.1\Components\Plc\Managed Libraries";

        /// <summary>
        /// Template Name for the XAE PLC Empty template
        /// </summary>
        public static string vsXaePlcEmptyTemplateName = "Empty PLC Template.plcproj";
        /// <summary>
        /// Template Name for the XAE PLC Standard template
        /// </summary>
        public static string vsXaePlcStandardTemplateName = "Standard PLC Template.plcproj";
        public static string projectName = "PlcProject";
        private XmlDocument xmlDoc;
        private string mappingFile = @"\ConfigFolder\ioMappingInfo.xml";
        private ITcSmTreeItem Peripherals = null;
        private ITcSmTreeItem TryLookUpItem;

        private ITcSmTreeItem _plcManager;
        public ITcSmTreeItem PlcManager
        {
            get { return _plcManager ?? (_plcManager = SystemManager.LookupTreeItem("TIPC")); }
            set { _plcManager = value; }
        }

        private ITcSmTreeItem _plcProject;
        public ITcSmTreeItem PlcProject
        {
            get { return _plcProject ?? (_plcProject = SystemManager.LookupTreeItem("TIPC^PlcProject^PlcProject Project")); }
            set { _plcProject = value; }
        }

        private ITcSmTreeItem _plcPeripheralsFolder;
        public ITcSmTreeItem PlcPeripheralsFolder
        {
            get { return _plcPeripheralsFolder ?? (_plcPeripheralsFolder = SystemManager.LookupTreeItem("TIPC^PlcProject^PlcProject Project^Peripherals")); }
            set { _plcPeripheralsFolder = value; }
        }

        #endregion
        /// <summary>
        /// Export IO varialbes
        /// </summary>
        /// <param name="peripherals"></param>
        /// <param name="slnPath"></param>
       public void ExportIo(List<Master> peripherals, string slnPath)
        {
            //lookup PlcProject
            CreatePlcProject();

            //handle library
            HandleLibrary(slnPath);

            //generate Io variables
            GeneratePeripheralsPou(peripherals);
        }

        //Create Peripherals IO plc code 
        #region
        /// <summary>
        /// create plc project when it not found!
        /// </summary>
        private void CreatePlcProject()
        {
            if (!TryLookupChild(PlcManager, projectName, out _plcProject))
            {
                //create plcProject 
                PlcProject = PlcManager.CreateChild(projectName, 0, "", vsXaePlcEmptyTemplateName);
                //Thread.Sleep(2000);
                ITcPlcProject plcProjectRootIec = (ITcPlcProject)PlcProject;
                if (TryLookupChild(PlcManager, "PlcProject", out _plcProject))
                {
                    plcProjectRootIec.BootProjectAutostart = true;
                    plcProjectRootIec.GenerateBootProject(true);

                    //create plc task
                    ITcSmTreeItem tasks = SystemManager.LookupTreeItem("TIRT");
                    if(!TryLookupChild(tasks, "PlcTask", out _plcProject))
                        tasks.CreateChild("PlcTask", 1, null, null);

                    //create Main Pou
                    if (!TryLookupChild(PlcProject, "Main", out _plcProject))
                        PlcProject.CreateChild("Main",(int)PouType.Program,null,null);

                    //create reference task
                    if (!TryLookupChild(PlcProject, "PlcTask", out _plcProject))
                    {
                        ITcSmTreeItem plcRefTask = PlcProject.CreateChild("PlcTask", (int)PouType.PlcTaskRef, null, null);
                        ITcPlcTaskReference plcTaskRef = (ITcPlcTaskReference)plcRefTask;
                        plcTaskRef.LinkedTask = "TIRT^PlcTask";
                        //plcRefTask.CreateChild("Main", 0, null, null);
                    }
                      
                }
            }
        }
        
        /// <summary>
        /// generate peripherals io in plc project
        /// </summary>
        /// <param name="peripherals"></param>
        private void GeneratePeripheralsPou(List<Master> peripherals)
        {
            ITcSmTreeItem plcProjectRoot = PlcProject.LookupChild(projectName+" Project");
            //generate IO pou
            if (!TryLookupChild(plcProjectRoot, "Peripherals", out Peripherals))
            {
                string[] vInfo;
                Peripherals = plcProjectRoot.CreateChild("Peripherals", (int)PouType.PLCFolder, "", null);

                //Peripheral variables
                ITcSmTreeItem PeripheralVar = Peripherals.CreateChild("Peripherals", (int)PouType.GlobalVariables, "", null);              
                if (TryLookupChild(Peripherals, "Peripherals", out _plcProject))
                {
                    //generate Peripheral variables
                    ITcPlcDeclaration plcDecl = (ITcPlcDeclaration)PeripheralVar;
                    plcDecl.DeclarationText = "///Mexan generate plc code\n" +
                                                "VAR_GLOBAL\n" +
                                                "\tBinIo : BinIo;\n" +
                                                "END_VAR\n" +
                                                "///Mexan end";
                }

                ITcSmTreeItem PeripheralRoot = Peripherals.CreateChild("PeripheralRoot", (int)PouType.FunctionBlock, "", null);

                //generate BinIO FB
                vInfo = new string[3];
                vInfo[0] = ((int)IECLANGUAGETYPES.IECLANGUAGE_ST).ToString();
                vInfo[1] = "Implements";
                vInfo[2] = "IMexanBinaryIo";
                ITcSmTreeItem Binio = Peripherals.CreateChild("BinIo", (int)PouType.FunctionBlock, "", vInfo);
                if (TryLookupChild(Peripherals, "BinIo", out _plcProject))
                {
                    //generate BinIO declaration
                    ITcPlcDeclaration binIODecl = (ITcPlcDeclaration)Binio;
                    binIODecl.DeclarationText = GenerateBinIODecl(peripherals, Binio);

                    vInfo = new string[2];
                    vInfo[0] = ((int)IECLANGUAGETYPES.IECLANGUAGE_ST).ToString();
                    vInfo[1] = "BOOL";
                    ITcSmTreeItem BusOk = Binio.CreateChild("BusIsOk", (int)PouType.Method, "", vInfo);
                    ITcPlcImplementation busOk = (ITcPlcImplementation)BusOk;
                    busOk.ImplementationText = "\tBusIsOk := TRUE;";

                    vInfo = new string[2];
                    vInfo[0] = ((int)IECLANGUAGETYPES.IECLANGUAGE_ST).ToString();
                    vInfo[1] = "BOOL";
                    ITcSmTreeItem GetState = Binio.CreateChild("GetState", (int)PouType.Method, "", vInfo);
                    ITcPlcDeclaration getStateDecl = (ITcPlcDeclaration)GetState;
                    getStateDecl.DeclarationText = "METHOD GetState : BOOL\r"+
                                                   "VAR_INPUT\r" +
                                                    "\t//Index FOR binary IO variable\r" +
                                                    "\tIoIndex	: UDINT;\r" +
                                                    "END_VAR";
                    ITcPlcImplementation getStateImpl = (ITcPlcImplementation)GetState;
                    getStateImpl.ImplementationText = GetIOStateOrText(peripherals,"State");


                    vInfo = new string[2];
                    vInfo[0] = ((int)IECLANGUAGETYPES.IECLANGUAGE_ST).ToString();
                    vInfo[1] = "BOOL";
                    ITcSmTreeItem SetState = Binio.CreateChild("SetState", (int)PouType.Method, "", vInfo);
                    ITcPlcDeclaration SetStateDecl = (ITcPlcDeclaration)SetState;
                    SetStateDecl.DeclarationText = "METHOD SetState : BOOL\r" +                                                   
                                                   "VAR_INPUT\r" +
                                                   "\t//Index FOR binary IO variable\r" +
                                                    "\tIoIndex\t   : UDINT;\r" +
                                                    "\t//Setpoint state\r" +
                                                    "\tSetpointState\t   : BOOL;" +
                                                    "END_VAR";
                    ITcPlcImplementation setStateImpl = (ITcPlcImplementation)SetState;
                    setStateImpl.ImplementationText = SetIOState(peripherals);

                    ITcSmTreeItem GetText = Binio.CreateChild("GetText", (int)PouType.Method, "", null);
                    ITcPlcDeclaration getTextDecl = (ITcPlcDeclaration)GetText;
                    getTextDecl.DeclarationText = "METHOD GetText : EVENTADDLTEXT_T\r" +
                                                   "VAR_INPUT\r" +
                                                    "\t//Index FOR binary IO variable\r" +
                                                    "\tIoIndex	: UDINT;\r" +
                                                    "END_VAR";
                    ITcPlcImplementation getTextImpl = (ITcPlcImplementation)GetText;
                    getTextImpl.ImplementationText = GetIOStateOrText(peripherals,"Text");

                    ITcSmTreeItem UpdateInputs = Binio.CreateChild("UpdateInputs", (int)PouType.Method, "", null);
                    ITcPlcImplementation udateInputImpl = (ITcPlcImplementation)UpdateInputs;
                    udateInputImpl.ImplementationText = UpdateIO(peripherals,"Input");

                    ITcSmTreeItem UpdateOutputs = Binio.CreateChild("UpdateOutputs", (int)PouType.Method, "", null);
                    ITcPlcImplementation udateOutputImpl = (ITcPlcImplementation)UpdateOutputs;
                    udateOutputImpl.ImplementationText = UpdateIO(peripherals, "Output");
                }

            }
            else
            {
                //Peripherals = SystemManager.LookupTreeItem("TIPC^PlcProject^PlcProject Project^Peripherals");
                plcProjectRoot.DeleteChild("Peripherals");
                GeneratePeripheralsPou(peripherals);
            }
        }

        /// <summary>
        /// Generate FB_BinIO  declaration
        /// </summary>
        /// <param name="peripherals"></param>
        /// <param name="itself"></param>
        /// <returns></returns>
        private string GenerateBinIODecl(List<Master> peripherals, ITcSmTreeItem itself)
        {
            string infoType;
            string retText = "";
            ITcPlcDeclaration itemDecl = (ITcPlcDeclaration)itself;
            string title = itemDecl.DeclarationText.Substring(0, itemDecl.DeclarationText.IndexOf("\n")) + "\r";
            string head = "///Mexan generate info. Mode = OverWriteAll\r";

            //generate input IO
            infoType = "Input";
            retText = retText + GenerateIODecl(peripherals, infoType);

            //Generate Output IO
            infoType = "Output";
            retText = retText + GenerateIODecl(peripherals, infoType);

            //Generate Bus Input IO
            infoType = "BusInput";
            retText = retText + GenerateIODecl(peripherals, infoType);

            //Generate Bus Output IO
            infoType = "BusOutput";
            retText = retText + GenerateIODecl(peripherals, infoType);

            //Generate IDX contant
            retText = retText + "VAR_OUTPUT CONSTANT\r";
            string idx = "IDX";
            int i = 1;
            foreach (Master item in peripherals)
            {
                foreach (Box b in item.Boxes)
                {
                    foreach (Terminal t in b.Terminals)
                    {
                        foreach (Variable v in t.Variables)
                        {
                            if ((v.IOType == "Input"|| v.IOType == "Output" ) && !v.Symbol.StartsWith("Input") && !v.Symbol.StartsWith("Output") && v.Symbol != "")
                            {
                                if (v.Symbol.StartsWith("_"))
                                    idx = "IDX";
                                else
                                    idx = "IDX_";
                                retText = retText + "\t///" + v.Comment + "\r" + "\t" + idx + v.Symbol + "\t : UDINT := " + i.ToString() + ";\r";
                                i++;
                            }
                        }
                    }
                }
            }
            retText = retText + "END_VAR\r///Mexan_generate_end.";

            retText = title + head + retText; 
            return retText;
        }

        /// <summary>
        /// generate Binio Delaration IO variables
        /// </summary>
        /// <param name="peripherals"></param>
        /// <param name="infoType"></param>
        /// <returns></returns>
        private string GenerateIODecl(List<Master> peripherals,string infoType)
        {

            string retText = "";
            string headText = "";
            string IOType = "";
            string commonText = "";
            string bus = "bus";
            string conectChar = "";
            switch (infoType)
            {
                case "Input":
                    headText = "VAR_INPUT\r\t//--- Digital Inputs ---\r";
                    IOType = "Input";
                    commonText = "\t : \t BOOL;\r";
                    bus = "";
                    break;

                case "Output":
                    headText = "VAR_OUTPUT\r\t//--- Digital Outputs ---\r";
                    IOType = "Output";
                    commonText = "\t : \t BOOL;\r";
                    bus = "";
                    break;

                case "BusInput":
                    headText = "VAR\r";
                    IOType = "Input";
                    commonText = "\t AT %I*\t: \t BOOL;\r";
                    bus = "bus";
                    break;

                case "BusOutput":
                    headText = "VAR\r";
                    IOType = "Output";
                    commonText = "\t AT %Q*\t: \t BOOL;\r";
                    bus = "bus";
                    break;

                case "IDX":
                    headText = "VAR_OUTPUT CONSTANT\r";
                    IOType = "Output";
                    commonText = "\t AT %Q*\t: \t BOOL;\r";
                    bus = "IDX";
                    break;


                default:
                    break;
            }

            retText = retText + headText;
            
            //generate from list
            foreach (Master item in peripherals)
            {
                foreach (Box b in item.Boxes)
                {
                    foreach (Terminal t in b.Terminals)
                    {
                        foreach (Variable v in t.Variables)
                        {
                            if (v.IOType == IOType && !v.Symbol.StartsWith(IOType))
                            {
                                if (bus == "bus")
                                {


                                    if (v.Symbol.StartsWith("_"))
                                        conectChar = "";
                                    else
                                        conectChar = "_";
                                }
                                retText = retText + "\t///" + v.Comment + "\r" + "\t" + bus + conectChar + v.Symbol + commonText;
                            }
                        }
                    }
                }
            }
            retText = retText + "END_VAR\r";
            return retText;
        }

        /// <summary>
        /// Generate GetState plc code
        /// </summary>
        /// <param name="peripherals"></param>
        /// <returns></returns>
        private string GetIOStateOrText(List<Master> peripherals,string infoType)
        {
            string retText = "";
            retText = retText + "CASE IoIndex OF\r";
            string idx = "IDX";
            foreach (Master item in peripherals)
            {
                foreach (Box b in item.Boxes)
                {
                    foreach (Terminal t in b.Terminals)
                    {
                        foreach (Variable v in t.Variables)
                        {
                            if (v.IOType == "Input"  && !v.Symbol.StartsWith("Input") && v.Symbol != "")
                            {
                                if (v.Symbol.StartsWith("_"))
                                    idx = "IDX";
                                else
                                    idx = "IDX_";

                                if(infoType == "State")
                                   retText = retText + "\t"+idx + v.Symbol + "\t\t\t : GetState := " + v.Symbol + ";\r";

                                if (infoType == "Text")
                                    retText = retText + "\t" + idx + v.Symbol + "\t\t\t : GetText := '" + v.Symbol +"("+v.Comment+")"+ "';\r";
                            }
                        }
                    }
                }
            }
            if (infoType == "State")
                retText = retText + "\r\tELSE\t GetState := FALSE;\r";

            if (infoType == "Text")
                retText = retText + "\r\tELSE\t GetText := '';\r";
            retText = retText + "END_CASE";
            return retText;
        }

        /// <summary>
        /// Generate SetState Plc code
        /// </summary>
        /// <param name="peripherals"></param>
        /// <returns></returns>
        private string SetIOState(List<Master> peripherals)
        {
            string retText = "";
            retText = retText + "SetState := TRUE;\r";
            retText = retText + "CASE IoIndex OF\r";
            string idx = "IDX";
            foreach (Master item in peripherals)
            {
                foreach (Box b in item.Boxes)
                {
                    foreach (Terminal t in b.Terminals)
                    {
                        foreach (Variable v in t.Variables)
                        {
                            if (v.IOType == "Input" && !v.Symbol.StartsWith("Input") && v.Symbol != "")
                            {
                                if (v.Symbol.StartsWith("_"))
                                    idx = "IDX";
                                else
                                    idx = "IDX_";

                                retText = retText + "\t" + idx + v.Symbol +"\t:"+  v.Symbol + "\t\t\t := SetpointState;\r";
                            }
                        }
                    }
                }
            }

            retText = retText + "\r\tELSE\t SetState := FALSE;\r";
            retText = retText + "END_CASE";
            return retText;
        }

        /// <summary>
        /// generate Update IO code
        /// </summary>
        /// <param name="peripherals"></param>
        /// <param name="InOut"></param>
        /// <returns></returns>
        private string UpdateIO(List<Master> peripherals, string InOut)
        {
            string retText = "";
            string bus = "bus";
            foreach (Master item in peripherals)
            {
                foreach (Box b in item.Boxes)
                {
                    foreach (Terminal t in b.Terminals)
                    {
                        foreach (Variable v in t.Variables)
                        {
                            if (v.IOType == InOut && !v.Symbol.StartsWith(InOut) && v.Symbol != "")
                            {
                                if (v.Symbol.StartsWith("_"))
                                    bus = "bus";
                                else
                                    bus = "bus_";

                                if(InOut == "Input")
                                    retText = retText +  v.Symbol + "\t\t\t :=" + bus + v.Symbol + ";\r";
                                if(InOut == "Output")
                                    retText = retText + bus + v.Symbol + "\t\t\t :=" + v.Symbol + ";\r";
                            }
                        }
                    }
                }
            }
            return retText;
        }
        #endregion

        /// <summary>
        /// Variables mapping
        /// </summary>
        /// <param name="peripherals"></param>
        public void LinkVariables(List<Master> peripherals, SlnLocation slnPathInfo)
        {
            string bus ;
            string channelName;
            string plcPath ;
            string ioPath ;
            int offset;

            //link failed info
            List<linkInfo> linkInfos = new List<linkInfo>();
           
            foreach (Master item in peripherals)
            {
                foreach (Box b in item.Boxes)
                {
                    foreach (Terminal t in b.Terminals)
                    {
                        foreach (Variable v in t.Variables)
                        {
                            if ((v.IOType == "Input" || v.IOType == "Output") && (!v.Symbol.StartsWith("Input") && !v.Symbol.StartsWith("Output")))
                            {
                                if (v.Symbol.StartsWith("_"))
                                    bus = "bus";
                                else
                                    bus = "bus_";
                                if (v.Channel.IndexOf("_") > 0)
                                    channelName = v.Channel.Substring(0, v.Channel.IndexOf("_"));
                                else
                                    channelName = v.Channel;

                                //get ioPath differ Io length
                                if (v.Count > 1)
                                    // for festo CPX-FB37/FB38
                                    ioPath = "TIID^" + item.Name + "^" + b.Name + "^" + t.Name + "^" + channelName + "^" + v.SubChannel;
                                else
                                    ioPath = "TIID^" + item.Name + "^" + b.Name + "^" + t.Name + "^" + channelName + "^" + v.Symbol;

                                //get plcPath differ IoType
                                if (v.IOType == "Input")                     
                                    plcPath = "TIPC^PlcProject^PlcProject Instance^PlcTask Inputs^Peripherals.BinIo." + bus + v.Symbol;                     
                                else                                
                                    plcPath = "TIPC^PlcProject^PlcProject Instance^PlcTask Outputs^Peripherals.BinIo." + bus + v.Symbol;

                                if (v.Count > 1)
                                {
                                    // for festo CPX-FB37/FB38
                                    offset = int.Parse(v.Channel.Substring(v.Channel.IndexOf("bit") - 2, 1));
                                    
                                     try
                                     {
                                         SystemManager.LinkVariables(ioPath, plcPath, offset, 0, 1);
                                     }
                                     catch
                                     {
                                         linkInfos.Add( new linkInfo { IoPath = ioPath , PlcPath = plcPath ,IoOffset = offset, PlcOffset = 0});
                                     }
                                }
                                else
                                {
                                     try
                                     {
                                         SystemManager.LinkVariables(ioPath, plcPath);
                                     }
                                     catch
                                     {
                                         linkInfos.Add(new linkInfo { IoPath = ioPath, PlcPath = plcPath, IoOffset = 0, PlcOffset = 0 });
                                     }
                                }
                                 
                            }
                        }
                    }
                }
            }
            
            //check failed link info
            if(linkInfos.Count > 0)
            {
                string linkInfoPath = slnPathInfo.Directory + @"\ConfigFolder\LinkInfo.txt";
                //write text
                FileStream fs = new FileStream(linkInfoPath, FileMode.Create, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                foreach (linkInfo info in linkInfos)
                {
                    sw.WriteLine(info.IoPath+"--------"+info.PlcPath+"\t\t\t"+DateTime.Now.ToString("HH:mm:ss"));
                }
                sw.Close();
                fs.Close();

                //display link failed info
                string msg = "部分变量链接失败，可在文件中查看！路径："+ linkInfoPath;
                MainViewModel.ShowMessage(msg);
            }                       
        }

        /// <summary>
        /// generate mapping infomation
        /// </summary>
        /// <param name="ioInfoPath"></param>
        /// <returns></returns>
        private bool GenerateMappingInfo(string ioInfoPath)
        {
            string mappingPath = Path.GetDirectoryName(ioInfoPath) + mappingFile;
            string tempMappingPath = Path.GetDirectoryName(ioInfoPath) + @"\ConfigFolder\tempMappingInfo.xml";
            try
            {
                xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(SystemManager.ProduceMappingInfo());
                xmlDoc.Save(mappingPath);
            }
            catch
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// import mapping infomation from xml
        /// </summary>
        public bool ConsumeMapping(string ioInfoPath)
        {
            bool result = false;
            string mappingPath = Path.GetDirectoryName(ioInfoPath) + mappingFile;
            if(File.Exists(mappingPath))
            {
                try
                {
                    //system function can't relize
                    xmlDoc = new XmlDocument();
                    xmlDoc.Load(mappingPath);
                    SystemManager.ClearMappingInfo();
                    SystemManager.ConsumeMappingInfo(xmlDoc.OuterXml);
                    result = true;
                }
                catch
                {
                    result = false;
                }
            }
            return result;
        }


        /// <summary>
        /// Add/remove library
        /// </summary>
        public void HandleLibrary(string slnPath)
        {
            string libFolder = Path.GetDirectoryName(slnPath) + @"\Library";
            if (TryLookupChild(PlcManager, projectName, out _plcProject))
            {
                ITcSmTreeItem references = _systemManager.LookupTreeItem("TIPC^PlcProject^PlcProject Project^References");
                ITcPlcLibraryManager libraryManager = (ITcPlcLibraryManager)references;

                //add library
                AddLibrary(libraryManager,libFolder);

            }

        }

        private XElement xmlLibInfo;
        private string libName;
        private string libVendor;
        private string libVersion;
        /// <summary>
        /// install and add library
        /// </summary>
        /// <param name="libraryManager"></param>
        /// <param name="path"></param>
        private void AddLibrary(ITcPlcLibraryManager libraryManager, string path)
        {
            // foreach (ITcPlcLibRepository repo in libraryManager.Repositories)
            // {
            //     Console.WriteLine("Found repository " + repo.Name + " in folder " + repo.Folder);
            // }

            if (Directory.Exists(path))
            {
                string[] libFiles = Directory.GetFiles(path);
                foreach (string lib in libFiles)
                {
                    //find out libraryInfo file
                    if (Path.GetFileNameWithoutExtension(lib) == "LibraryInfo")
                    {
                        try
                        {
                            xmlLibInfo = XElement.Load(lib);
                            libName = xmlLibInfo.Element("library").Attribute("Name").Value;
                            libVendor = xmlLibInfo.Element("library").Attribute("Vendor").Value;
                            libVersion = xmlLibInfo.Element("library").Attribute("Version").Value;
                        }
                        catch
                        {
                            //to do
                        }                   
                    }
                        
                    //find out library file
                    if (Path.GetExtension(lib) == ".library" || Path.GetExtension(lib) == ".compiled-library" || Path.GetExtension(lib) == ".compiled-library-ge33")
                    {
                        // library development by cunstom
                        if(Path.GetExtension(lib) == ".library" || Path.GetExtension(lib) == ".compiled-library")
                        {
                            //install library
                            libraryManager.InstallLibrary("System", lib, true);

                            //remove library first 
                            try
                            {
                                if (Path.GetFileNameWithoutExtension(lib) == libName)
                                    libraryManager.RemoveReference(Path.GetFileNameWithoutExtension(lib));
                            }
                            catch
                            {
                                //to do
                            }

                            //add library
                            try
                            {                               
                                if (Path.GetFileNameWithoutExtension(lib) == libName)
                                    libraryManager.AddLibrary(Path.GetFileNameWithoutExtension(lib), "*", libVendor);
                                else
                                    libraryManager.AddLibrary(Path.GetFileNameWithoutExtension(lib), "*", "");
                            }
                            catch
                            {
                                //to do
                            }
                        }

                        // library development by beckhoff
                        if (Path.GetExtension(lib) == ".compiled-library-ge33")
                        {
                            try
                            {
                                //libraryManager.RemoveReference(Path.GetFileNameWithoutExtension(lib));
                                libraryManager.AddLibrary(Path.GetFileNameWithoutExtension(lib), "*", "");
                            }
                            catch
                            {
                                //to do
                            }
                        }
                    }
                }

                //get all directory 
                string[] directoryInfo = Directory.GetDirectories(path);
                foreach (string libFolder in directoryInfo)
                {
                    AddLibrary(libraryManager, libFolder);
                }
            }
        }

        /// <summary>
        /// check if child exsit
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="childName"></param>
        /// <param name="child"></param>
        /// <returns></returns>
        private bool TryLookupChild(ITcSmTreeItem parent, string childName, out ITcSmTreeItem child)
        {
            foreach (ITcSmTreeItem c in parent)
            {
                if (c.Name == childName)
                {
                    child = c;
                    return true;
                }
            }
            child = null;
            return false;
        }

        private bool TryQueryChild(ITcSmTreeItem parent, string childName)
        {
            foreach (ITcSmTreeItem c in parent)
            {
                if (c.Name == childName)
                {                  
                    return true;
                }
            }
            return false;
        }

        private bool TryQueryChildWihoutRejected(ITcSmTreeItem parent, string childName)
        {
            bool result = false;
            Func<ITcSmTreeItem, string,bool> func = TryQueryChild;
            result = ExceptionHandler.RunWithOutRejectedFunc<bool>(func, parent, childName);
            return result;
        }
    }
}
