﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Tc3Enginner.Model;

namespace Tc3Enginner.Common
{
    class ReadConfig
    {
        private List<Master> _peripherals = new List<Master>();
        private List<Master> _oldConfig;
        private bool _readConfigFromTc3;
        private string _ioType = "Neither";
        private bool masterEqual = false;
        private bool boxEqual = false;
        private bool terminalEqual = false;
        #region
        //获取*.xti数据
        /// <summary>
        /// 获取硬件信息
        /// </summary>
        /// <returns></returns>
        public List<Master> ReadIoFromTcSln(string path,List<Master> oldConfig,bool readFromTc3)
        {
            List<Master> emptyMasterList = new List<Master>();
            //get the old configration
            _oldConfig = oldConfig;
            _readConfigFromTc3 = readFromTc3;

            _peripherals = emptyMasterList;
            XElement xRoot = XElement.Load(path);
            /*
            _peripherals = (from n in xRoot.Elements("Device")
                            select new Master
                            {
                                Id = n.Attribute("Id").Value,
                                Name = n.Attribute("RemoteName").Value,
                                Boxes = GetBox(n)
                            }).ToList();
            */
            foreach(XElement n in xRoot.Elements("Device"))
            {
                //compare old and new configration
                Master _curMaster = null;
                masterEqual = false;
                if (_oldConfig != null)
                {
                    foreach (Master m in _oldConfig)
                    {
                        if (m.Id == n.Attribute("Id").Value && m.Name == n.Attribute("RemoteName").Value)
                        {
                            masterEqual = true;
                            _curMaster = m;
                        }
                    }
                }
                _peripherals.Add( new Master { Id = n.Attribute("Id").Value, Name = n.Attribute("RemoteName").Value, Boxes = GetBox(n, _curMaster) });
            }

            return _peripherals;
        }


        private List<Box> _box = new List<Box>();
        /// <summary>
        /// 获取Box信息,Device\Box
        /// </summary>
        /// <param name="xElement"></param>
        /// <returns></returns>
        private List<Box> GetBox(XElement xElement,Master curMaster)
        {
            /*
            _box = (from n in xElement.Elements("Box")
                    select new Box
                    {
                        Id = n.Attribute("Id").Value,
                        Name = n.Element("Name").Value,
                        Terminals = GetTerminal(n)
                    }).ToList();
            */
            List<Box> emptyBoxList = new List<Box>();
            _box = emptyBoxList;

            foreach (XElement n in xElement.Elements("Box"))
            {
                //compare old and new configration
                Box curBox = null;
                boxEqual = false;
                if(curMaster != null)
                {
                    foreach (Box m in curMaster.Boxes)
                    {
                        if (m.Id == n.Attribute("Id").Value && m.Name == n.Element("Name").Value)
                        {
                            boxEqual = true;
                            curBox = m;
                        }

                    }
                }
                _box.Add(new Box { Id = n.Attribute("Id").Value, Name = n.Element("Name").Value, Terminals = GetTerminal(n,curBox) });
            }

            return _box;
        }

        private List<Terminal> _terminalBox = new List<Terminal>();
        private List<Terminal> _terminalPdo = new List<Terminal>();
        private List<Terminal> _terminal = new List<Terminal>();
        /// <summary>
        /// 获取Terminal信息
        /// </summary>
        /// <param name="xElement"></param>
        /// <returns></returns>
        private List<Terminal> GetTerminal(XElement xElement, Box curBox)
        {
            // int _countBox = xElement.Elements("Box").Count(); 
            //int _countPdo = xElement.Element("EtherCAT").Elements("Pdo").Count(); 
            List<Terminal> _emptyTerList = new List<Terminal>();
            List<Variable> _emptyVarList = new List<Variable>();
            _terminal = _emptyTerList;

            //find Device\Box\Box for Beckhoff EL/KL module
            if (xElement.Elements("Box").Count() > 0)
            {
                /*  _terminal = (from n in xElement.Elements("Box")
                               where n.Element("EtherCAT").Attribute("SlaveType").Value == "1"
                               select new Terminal
                               {
                                   Id == n.Attribute("Id").Value
                                   Name = n.Element("Name").Value,
                                   Variables = GetBoxVariable(n)
                               }).ToList(); */
                foreach (XElement n in xElement.Elements("Box"))
                {
                    //compare old and new configration
                    Terminal curTerminal = null;
                    terminalEqual = false;
                    if( curBox != null)
                    {
                        foreach (Terminal m in curBox.Terminals)
                        {
                            if (m.Id == n.Attribute("Id").Value && m.Name == n.Element("Name").Value)
                            {
                                terminalEqual = true;
                                curTerminal = m;
                            }
                        }
                    }
                    //check io type
                    if (n.Element("EtherCAT").Attribute("Type").Value.IndexOf("Input") > 0)
                        _ioType = "Input";
                    if (n.Element("EtherCAT").Attribute("Type").Value.IndexOf("Output") > 0)
                        _ioType = "Output";

                    //get variables
                    if (n.Element("EtherCAT").Attribute("SlaveType").Value == "1")
                        _terminal.Add(new Terminal { Id = n.Attribute("Id").Value, Name = n.Element("Name").Value, Variables = GetBoxVariable(n) });
                    else
                        _terminal.Add(new Terminal { Id = n.Attribute("Id").Value, Name = n.Element("Name").Value, Variables = _emptyVarList });
                }
            }

            //find Device\Box\Box\Slot  for for festo CPX-FB37/38 module Module/slot
            if (xElement.Elements("EtherCAT").Count() > 0)
            {
                if (xElement.Element("EtherCAT").Elements("Slot").Count() > 0)
                {
                    foreach (XElement m in xElement.Element("EtherCAT").Elements("Slot"))
                    {
                        if (m.Elements("Module").Count() > 0 && m.Element("Module").Elements("PdoIndex").Count() > 0)
                        {
                            int x = int.Parse(m.Element("Module").Element("PdoIndex").Value);

                            // _terminal = (from n in xElement.Element("EtherCAT").Elements("Pdo")
                            //              where Convert.ToInt32(Int32.Parse(n.Attribute("Index").Value.Substring(2),System.Globalization.NumberStyles.HexNumber)) == x //int.Parse(m.Element("Module").Element("PdoIndex").Value)
                            //              select new Terminal
                            //              {
                            //                  //Name = n.Attribute("Name").Value,
                            //                  Name = m.Element("Module").Element("Name").Value,
                            //                  Variables = GetPdoVariable(n)
                            //              }).ToList();

                            //compare old and new configration
                            Terminal curTerminal = null;
                            terminalEqual = false;
                            if(curBox != null)
                            {
                                foreach (Terminal t in curBox.Terminals)
                                {
                                    if (t.Id == m.Element("Module").Element("PdoIndex").Value && t.Name == m.Element("Module").Element("Name").Value)
                                    {
                                        terminalEqual = true;
                                        curTerminal = t;
                                    }
                                }
                            }
                            foreach (XElement n in xElement.Element("EtherCAT").Elements("Pdo"))
                            {
                                //find the Pdo match with Slot
                                int y = Convert.ToInt32(Int32.Parse(n.Attribute("Index").Value.Substring(2), System.Globalization.NumberStyles.HexNumber));

                                if (x == y)
                                {
                                    

                                    //check io type
                                    if (n.Attribute("Name").Value == "Inputs")
                                        _ioType = "Input";
                                    if (n.Attribute("Name").Value == "Outputs")
                                        _ioType = "Output";

                                    //get variables
                                    if (xElement.Element("EtherCAT").Attribute("SlaveType").Value == "2")
                                        _terminal.Add(new Terminal { Id = m.Element("Module").Element("PdoIndex").Value, Name = m.Element("Module").Element("Name").Value, Variables = GetPdoVariable(n, curTerminal) });
                                    else
                                        _terminal.Add(new Terminal { Id = m.Element("Module").Element("PdoIndex").Value, Name = m.Element("Module").Element("Name").Value, Variables = _emptyVarList });
                                }

                            }

                        }
                    }

                }
            }
            return _terminal;
        }

        /// <summary>
        /// 获取Box Terminal IO
        /// </summary>
        private List<Variable> _variable = new List<Variable>();
        private List<Variable> GetBoxVariable(XElement xElement)
        {
            // XElement xEle = xElement.Element("EtherCAT");
            List<Variable> _emptyList = new List<Variable>();
            _variable = _emptyList;
            if (xElement != null && xElement.Element("EtherCAT").Elements("Pdo").Count() > 0)
            {
                /* _variable = (from n in xElement.Element("EtherCAT").Elements("Pdo")
                              select new Variable
                              {
                                  Channel = n.Attribute("Index").Value.Remove(0,n.Attribute("Index").Value.Length-2),
                                  //Channel = n.Attribute("Index").Value,
                                  Symbol = n.Element("Entry").Attribute("Name").Value,
                                  // Comment = n.Element("Comment").Value,
                                  Comment = "Reserve"
                              }).ToList();*/
                foreach (XElement n in xElement.Element("EtherCAT").Elements("Pdo"))
                {
                    string _comment;
                    if (n.Element("Entry").Elements("Comment").Count() > 0)
                        _comment = n.Element("Entry").Element("Comment").Value;
                    else
                        _comment = "Reserved";
                    _variable.Add(new Variable
                    {
                        Id = n.Attribute("Index").Value,
                        //Channel = n.Attribute("Index").Value.Remove(0, n.Attribute("Index").Value.Length - 2),
                        Channel = n.Attribute("Name").Value,
                        SubChannel = "",
                        IOType = _ioType,
                        Symbol = n.Element("Entry").Attribute("Name").Value,
                        Comment = _comment,
                        Count = 1,
                    });

                }
                return _variable;
            }
            else
                return _emptyList;
        }

        /// <summary>
        /// 获取Pdo Io for festo CPX-FB37/38 module
        /// </summary>
        /// <param name="xElement"></param>
        /// <returns></returns>
        private List<Variable> GetPdoVariable(XElement xElement, Terminal curTurminal)
        {
            List<Variable> _emptyVarList = new List<Variable>();
            _variable = _emptyVarList;
            if (xElement != null)
            {
                /* _variable = (from n in xElement.Elements("Entry")
                              where n.Attributes("Sub").Count()>0
                              where n.Attributes("Name").Count() > 0
                              //where n.Attributes("Sub").Count() > 0
                              select new Variable
                              {

                                  Channel = n.Attribute("Sub").Value.Remove(0, n.Attribute("Sub").Value.Length - 2),
                                  Symbol = n.Attribute("Name").Value,
                                   Comment = "Reserve",
                              }).ToList();*/
                foreach (XElement n in xElement.Elements("Entry"))
                {
                    //for Bit variables
                    if (n.Element("Type").Value == "BIT")
                    {
                        string _comment;
                        if (n.Elements("Comment").Count() > 0)
                            _comment = n.Element("Comment").Value;
                        else
                            _comment = "Reserved";
                        _variable.Add(new Variable
                        {
                            Id = n.Attribute("Index").Value + n.Attribute("Sub").Value,
                            //Channel = n.Attribute("Sub").Value.Remove(0, n.Attribute("Sub").Value.Length - 2),
                            Channel = xElement.Attribute("Name").Value + "_" +  n.Attribute("Sub").Value.Remove(0, n.Attribute("Sub").Value.Length - 2),
                            SubChannel = "",
                            IOType = _ioType,
                            Symbol = n.Attribute("Name").Value,
                            Comment = _comment,
                            Count = 1,
                        });
                    }
                    
                    //for int variables for festo CPX-FB37/38 module
                    if (n.Element("Type").Value == "USINT")
                    {
                        if (masterEqual && boxEqual && terminalEqual && curTurminal != null && _readConfigFromTc3)
                        {
                            _variable = curTurminal.Variables;
                        }
                        else
                        {
                            string _comment, _symbol;
                            _symbol = n.Attribute("Name").Value;
                            if (n.Elements("Comment").Count() > 0)
                                _comment = n.Element("Comment").Value;
                            else
                                _comment = "Reserved";

                            for (int i = 0; i < 8; i++)
                            {
                                //when read from file and comment exist
                                string varEle = "Variable" + i.ToString();
                                if (n.Elements(varEle).Count() > 0)
                                {
                                    _comment = n.Element(varEle).Attribute("Comment").Value;
                                    _symbol = n.Element(varEle).Attribute("Name").Value;
                                  //  foreach (XElement v in n.Elements(varEle))
                                  //  {
                                  //      if(int.Parse(v.Attribute("Channel").Value) == i)
                                  //      {
                                  //          _comment = v.Attribute("Comment").Value;
                                  //          _symbol = v.Attribute("Name").Value;
                                  //      }
                                  //  }
                                }
                                _variable.Add(new Variable
                                {
                                    Id = n.Attribute("Index").Value + n.Attribute("Sub").Value,
                                    Channel = xElement.Attribute("Name").Value + "_" + n.Attribute("Sub").Value.Remove(0, n.Attribute("Sub").Value.Length - 2) + "  " + i.ToString() + " bit",
                                    SubChannel = n.Attribute("Name").Value,
                                    IOType = _ioType,
                                    Symbol = _symbol,
                                    Comment = _comment,
                                    Count = 8
                                });
                            }
                        }
                    }

                }
                return _variable;
            }
            else
                return _emptyVarList;
        }
        #endregion
    }
}
