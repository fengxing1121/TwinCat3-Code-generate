﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc3Enginner.Common
{
    class ScriptInfo
    {
    }
    /* ===============================================================================================
    * Enum which represents a PlcObjectType from Orders.xml
    * Example: <PlcObject type="Library">
    * =============================================================================================== */
    public enum PlcObjectType
    {
        DataType,
        Library,
        Placeholder,
        POU,
        Itf,
        Gvl
    }
    /// <summary>
    /// POU Type, POU subType
    /// </summary>
    public enum PouType
    {
        PLCAPP = 600,
        PLCFolder = 601,
        Program ,
        Function,
        FunctionBlock,
        Enum,
        Struct,
        Union,
        Action,
        Method ,
        IMethod,
        Property,
        IProperty,
        PropertyGet,
        PropertySet,
        GlobalVariables,
        Transition,
        PlcLibManager,
        Interface = 618,
        PlcTaskRef = 621,
        PlcProgramRef,
        Alias = 623,
        ParameterList = 629,
        UMLClassDiagram = 631,
        IPropertyGet = 654,
        IPropertySet,
    }

    public class linkInfo
    {
        public string IoPath { get; set; }
        public string PlcPath { get; set; }   
        public int IoOffset { get; set; }
        public int PlcOffset { get; set; }
    }

}
