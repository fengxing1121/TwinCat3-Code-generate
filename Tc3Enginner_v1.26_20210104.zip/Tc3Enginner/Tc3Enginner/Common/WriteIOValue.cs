﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Tc3Enginner.Model;

namespace Tc3Enginner.Common
{
    class WriteIOValue
    {
        #region
        //根据List 数据修改*.xti文件
        public void SaveData(List<Master> Peripherals,string path, bool WriteValueToTc3)
        {
            XElement xRoot = XElement.Load(path);
            foreach (Master m in Peripherals)
                foreach (Box b in m.Boxes)
                {
                    IEnumerable<XElement> be = from bl in xRoot.Element("Device").Elements("Box")
                                               where bl.Attribute("Id").Value == b.Id
                                               select bl;

                    foreach (Terminal t in b.Terminals)
                    {
                        //Terminal为Box io
                        IEnumerable<XElement> te = from tl in be.Descendants("Box")
                                                   where tl.Attribute("Id").Value == t.Id
                                                   select tl;

                        //Terminal 为Pdo io
                        IEnumerable<XElement> se = from sl in be.Descendants("Slot")
                                                   where sl.Elements("Module").Count() > 0
                                                   where sl.Element("Module").Element("PdoIndex").Value == t.Id
                                                   select sl;
                        
                        //Box IO variable
                        if (te.Count() > 0)
                        {
                            //查询对应id的IO
                            foreach (Variable v in t.Variables)
                            {
                                /*
                                //收集io
                                IEnumerable<XElement> el = from ee in te.Descendants("Pdo")
                                                           where ee.Attribute("Index").Value == v.Id
                                                           select ee;
                                                           */
                                //更改io
                                foreach (XElement x in te.Descendants("Pdo"))
                                {
                                    if (x.Attribute("Index").Value == v.Id)
                                    {
                                        //modify IO symbol
                                        if (x.Element("Entry").Attribute("Name").Value != v.Symbol)
                                        { x.Element("Entry").SetAttributeValue("Name", v.Symbol); }
                                        //Modify IO comment
                                        if (x.Element("Entry").Elements("Comment").Count() == 0)
                                        {
                                            x.Element("Entry").Add(new XElement("Comment", new XCData(v.Comment)));
                                        }
                                        else
                                             if (x.Element("Entry").Element("Comment").Value != v.Comment)
                                        {
                                            x.Element("Entry").Elements("Comment").Remove();
                                            x.Element("Entry").Add(new XElement("Comment", new XCData(v.Comment)));
                                        }
                                    }
                                }
                            }
                        }

                        //Pdo IO variable
                        if (se.Count() > 0)
                        {
                            /*
                            //查询对应id的IO
                            foreach (Variable v in t.Variables)
                            {
                                IEnumerable<XElement> el = from ee in te.Descendants("Entry")
                                                           where ee.Attribute("Index").Value + ee.Attribute("Sub").Value == v.Id
                                                           select ee;
                            }
                            */
                            //Terminal 为Pdo io
                            IEnumerable<XElement> pe = from pl in be.Descendants("Pdo")
                                                       //where pl.Elements("Entry").Count() > 0
                                                       //where pl.Attribute("Index").Value == t.Id
                                                       where Convert.ToInt32(Int32.Parse(pl.Attribute("Index").Value.Substring(2), System.Globalization.NumberStyles.HexNumber)) == int.Parse(t.Id)
                                                       select pl;

                            foreach (Variable v in t.Variables)
                            {
                                //modify io                                
                                foreach (XElement x in pe.Descendants("Entry"))
                                {
                                    if (x.Element("Type").Value == "USINT")
                                    {
                                        //no modify when write value to tc3, avalable only when saving data
                                        string enetryChannel;
                                        string bitElement;
                                        int offset;
                                        if (!WriteValueToTc3)
                                        {
                                            enetryChannel = "#x" + v.Channel.Substring(v.Channel.IndexOf("_")+1,2);
                                            if(x.Attribute("Sub").Value == enetryChannel)
                                            {
                                                offset = int.Parse(v.Channel.Substring(v.Channel.IndexOf("bit") - 2, 1));
                                                bitElement = "Variable" + offset.ToString();
                                                x.SetElementValue(bitElement, offset);
                                                x.Element(bitElement).SetAttributeValue("Channel", offset.ToString());
                                                x.Element(bitElement).SetAttributeValue("Name",v.Symbol);
                                                x.Element(bitElement).SetAttributeValue("Comment", v.Comment);
                                            }
                                        }
                                            
                                    }
                                    if(x.Element("Type").Value == "BIT")
                                    {
                                        if (x.Attributes("Index").Count() > 0 && x.Attributes("Sub").Count() > 0)
                                        {
                                            if (x.Attribute("Index").Value + x.Attribute("Sub").Value == v.Id)
                                            {
                                                //modify IO symbol
                                                if (x.Attribute("Name").Value != v.Symbol)
                                                { x.SetAttributeValue("Name", v.Symbol); }

                                                //Modify IO comment
                                                if (x.Elements("Comment").Count() == 0)
                                                {
                                                    x.Add(new XElement("Comment", new XCData(v.Comment)));
                                                }
                                                else
                                                     if (x.Element("Comment").Value != v.Comment)
                                                     {
                                                        x.Element("Comment").Remove();
                                                        x.Add(new XElement("Comment", new XCData(v.Comment)));
                                                     }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
            xRoot.Save(path);
        }
        #endregion
    }
}
