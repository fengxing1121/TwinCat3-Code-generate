﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc3Enginner.Model
{
   public class SlnLocation: ObservableObject
    {

        private string _fileName;
        private string _filePath;
        private string _directory;

        public string FileName
        {
            get { return _fileName; }
            set
            {
                _fileName = value;
                RaisePropertyChanged(() => FileName);
            }
        }
        public string FilePath
        {
            get { return _filePath; }
            set
            {
                _filePath = value;
                RaisePropertyChanged(() => FilePath);
            }
        }
        public string Directory
        {
            get { return _directory; }
            set
            {
                _directory = value;
                RaisePropertyChanged(() => Directory);
            }
        }
    }

}

