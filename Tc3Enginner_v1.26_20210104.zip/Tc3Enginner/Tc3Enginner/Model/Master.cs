﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using Tc3Enginner.Model;

namespace Tc3Enginner.Model
{
    #region
    //feildbus port
    public class Master
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public List<Box> Boxes { get; set; }
    }

    //terminal box
    public class Box
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public List<Terminal> Terminals { get; set; }
    }

    //pulic terminals
    public class Terminal
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public List<Variable> Variables { get; set; }
    }

    //variables in terminal
    public class Variable : ObservableObject
    {
        public string Id { get; set; }
        public string Channel { get; set; }
        public string SubChannel { get; set; }
        public string IOType { get; set; }
        private string _symbol;
        private string _comment;
        public uint Count { get; set; }

        /// <summary>
        /// 通道编号名称
        /// </summary>
        public string Symbol
        {
            get { return _symbol; }
            set { _symbol = value; RaisePropertyChanged(() => Symbol); }
        }
        /// <summary>
        /// IO文本注释
        /// </summary>
        public string Comment
        {
            get { return _comment; }
            set { _comment = value; RaisePropertyChanged(() => Comment); }
        }


    }
    #endregion


}
