﻿// Keep this lines for a best effort IntelliSense of Visual Studio 2017.
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\Lib\jquery.d.ts" />
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\TcHmi.d.ts" />
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\Controls\System\TcHmiControl\Source.d.ts" />

// Keep this lines for a best effort IntelliSense of Visual Studio 2013/2015.
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\Lib\jquery\jquery.js" />
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\TcHmi.js" />

(function (TcHmi) {
   
    var interval;

    function getDate() {
        var now = new Date();
        var day = now.getDate();
        var month = now.getMonth() + 1;
        var year = now.getFullYear();
        var hours = now.getHours();
        var minutes = now.getMinutes();

        var locale = TcHmi.Locale.get();

        day = formatNumber(day);
        month = formatNumber(month);
        minutes = formatNumber(minutes);

        var targetControl = TcHmi.Controls.get("TcHmiClockTime");

        if (!targetControl)
            return;

        if (locale === "en-US") {

            if (hours < 12) {
                if (hours === 0) {
                    hours = 12;
                }

                targetControl.setText(month + '/' + day + '/' + year + ' ' + hours + ':' + minutes + ' AM');
            } else {

                if (hours !== 12) {
                    hours = hours - 12;
                }

                targetControl.setText(month + '/' + day + '/' + year + ' ' + hours + ':' + minutes + ' PM');
            }

        } else {

            hours = formatNumber(hours);

            if (locale === "de-DE") {
                targetControl.setText(day + '.' + month + '.' + year + ' ' + hours + ':' + minutes + ' Uhr');
            } else {
                targetControl.setText(day + '.' + month + '.' + year + ' ' + hours + ':' + minutes);
            }
        }
    }

    function formatNumber(number) {
        return (number < 10 ? '0' : '') + number;
    }

    TcHmi.EventProvider.register("TcHmiClockTime.onInitialized", function (e, data) {

        interval = setInterval(getDate, 500);

    });

    TcHmi.EventProvider.register("TcHmiClockTime.onDestroyed", function (e, data) {

        if (interval) {
            clearInterval(interval);
        }

    });

})(TcHmi);
