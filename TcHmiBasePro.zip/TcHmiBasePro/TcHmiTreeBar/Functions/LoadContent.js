﻿// Provider for a best effort Intellisense of Visual Studio 2017.
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\Lib\jquery.d.ts" />
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\TcHmi.d.ts" />
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\Controls\System\TcHmiControl\Source.d.ts" />

// Provider for a best effort Intellisense of Visual Studio 2013/2015.
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\Lib\jquery\jquery.js" />
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\TcHmi.js" />

(function (TcHmi) {

    var LoadContent = function (TargetRegion,PageName) {
        if (TargetRegion !== null && TargetRegion !== undefined) {
            if (PageName) {
                // assumption: page is already defined with path
                if (PageName.match(".content")) {
                    TargetRegion.setTargetContent(PageName);
                } else {
                    var targetPath = 'Pages/' + PageName + '.content';
                    TargetRegion.setTargetContent(targetPath);
                }
            }
        }
    };

    TcHmi.Functions.registerFunction('LoadContent', LoadContent);
})(TcHmi);