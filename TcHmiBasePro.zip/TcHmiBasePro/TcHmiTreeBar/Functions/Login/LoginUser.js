﻿// Keep this lines for a best effort IntelliSense of Visual Studio 2017.
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\Lib\jquery.d.ts" />
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\TcHmi.d.ts" />
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\Controls\System\TcHmiControl\Source.d.ts" />

// Keep this lines for a best effort IntelliSense of Visual Studio 2013/2015.
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\Lib\jquery\jquery.js" />
/// <reference path="C:\TwinCAT\Functions\TE2000-HMI-Engineering\Infrastructure\TcHmiFramework\Latest\TcHmi.js" />

(function (TcHmi) {

    var LoginUser = function (Username,Password) {

        // check that username and password are valid
        if (!Username) {
            return false;
        }           

        if (!Password) {
            return false;
        }           

        // build write value
        var writeValue = {
            "userName": Username,
            "password": Password
        };

        TcHmi.Server.writeSymbol('Login', writeValue, function (data) {
            if (data.error !== TcHmi.Errors.NONE) {
                // Handle TcHmi.Server class level error here.
                return false;
            }
            var response = data.response;
            if (response.error !== undefined) {
                // Handle TwinCAT HMI Server response level error here.
                return false;
            }
            var commands = response.commands;
            if (commands === undefined) {
                return false;
            }
            var command = response.commands[0];
            if (command === undefined) {
                return false;
            }
            if (command.error !== undefined) {
                // user that was logged in was logged in again
                if (command.error.code === 4106) {
                    console.log("User already logged in");
                }

                return false;
            }           

            // if login succeeded, reload the window
            // because we could be on a page where we now don't have access to
            location.reload();
            return true;
        });

    };
    
    TcHmi.Functions.registerFunction('LoginUser', LoginUser);
})(TcHmi);